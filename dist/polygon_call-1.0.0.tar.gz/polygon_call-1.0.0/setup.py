from setuptools import setup

setup(
    name='polygon_call',
    version='1.0.0',
    packages=[''],
    url='',
    license='',
    author='Yuqi Tang',
    author_email='yt2101@nyu.edu',
    description='Repeatedly calls the polygon api every 1 seconds for 24 hours'
)
